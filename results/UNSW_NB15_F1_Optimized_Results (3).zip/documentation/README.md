# Comprehensive Data-Audited Multiclass NIDS — UNSW-NB15

Selected model: LightGBM (Mild Weights)
Selected preprocessing: S0_Raw
Selection policy: Macro-F1 maximized among candidates within 1.5 percentage points of the best mean validation accuracy
Validation protocol: 2 sampled duplicate-grouped screening folds (reduced tree counts)
Fast screen sampled-group fraction: 20% (minimum 20 groups per class)

The project predicts all ten `attack_cat` classes. CatBoost is not included. Unweighted XGBoost remains a reference candidate; the comparison includes regularized and class-weighted XGBoost/LightGBM variants, tree ensembles and an XGBoost–LightGBM soft-voting ensemble.

The data audit checks schema and column integrity, canonical target labels, training-only binary-label consistency, numeric conversion failures, missing/infinite/negative values, zero inflation, ranges, percentiles, skew, IQR outliers, categorical cardinality, duplicate raw-feature groups, conflicting labels, class/group counts, highly correlated features, and grouped-fold class coverage. Features are reported, not automatically deleted based solely on outlier or correlation flags.

Model selection uses duplicate-grouped training-only validation. In FAST_MODE, nine candidates are tested on two sampled grouped folds with reduced estimator counts; this is a fast preliminary screen. The final model is refitted on the full training data using full estimator settings. Set FAST_MODE=False for the longer three-fold screening and five-fold confirmation protocol. Feature importance, TTL ablation and input-corruption robustness use a grouped validation fold from the training partition. The official testing labels are first used for the final evaluation after the model is locked. Post-hoc test-set class mix, numerical shift, unseen categories and train/test exact overlap are descriptive only and must not be used to retune or reselect this model.

The GUI uses the exact same `prepare_model_features()` function as the training pipeline; engineered features are recalculated from the uploaded raw fields. The model outputs ten-class predictions and class probabilities. The probability maximum is a model confidence estimate, not a guarantee of correctness.

This is an offline file-based prototype. It does not capture live packets, block connections or automatically respond to attacks. Report all scores as measured; no target accuracy is guaranteed.
